import Button from 'react-bootstrap/Button';
import React, { useState } from 'react'
import Login from './Login'
import { Register  } from './Register';

 const Home = () => {
   
     const [isLogin, setIsLogin] = useState(false);
     const [isRegister, setIsRegister] = useState(false);
   
    return (
      


<>
            
  <div style={{float:"right"}}>
            <Button className='m-4' onClick={()=>setIsRegister(!isRegister)} variant="primary">Register</Button>
                <Button className='m-4'  onClick={() => setIsLogin(!isLogin)} variant="primary">Login</Button>
                
           


            </div>
            

            {isLogin && <Login />}
            {isRegister&& <Register/>}

        </>
        

      
  )
}
export default Home;